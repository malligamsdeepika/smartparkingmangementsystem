/**
 * Smart Parking Real-Time Multi-Device Synchronization Service
 * 
 * Uses WebSocket as Primary (<20ms latency) with automatic Server-Sent Events (SSE) fallback (<80ms)
 * to deliver instantaneous booking notifications and slot updates across multiple laptops, PCs, and phones.
 * 
 * Flow:
 * Laptop A (User books slot) -> Java Servlet/Node -> MySQL commit -> WebSocket/SSE push -> Laptop B (Admin Console < 1s)
 */

import { ApiService } from './api';

export type RealtimeStatus = 'connected' | 'connecting' | 'disconnected' | 'reconnecting';
export type RealtimeTransport = 'websocket' | 'sse' | 'none';

export interface RealtimeEventPayload {
  eventType: string;
  payload: any;
  timestamp: string;
  activeClientsCount?: number;
  transport?: RealtimeTransport;
}

type EventCallback = (event: RealtimeEventPayload) => void;

class RealtimeSyncManager {
  private socket: WebSocket | null = null;
  private eventSource: EventSource | null = null;
  private status: RealtimeStatus = 'disconnected';
  private transport: RealtimeTransport = 'none';
  private listeners: Set<EventCallback> = new Set();
  private statusListeners: Set<(status: RealtimeStatus, clientCount: number, transport: RealtimeTransport) => void> = new Set();
  private reconnectTimeout: any = null;
  private pingInterval: any = null;
  private reconnectAttempts = 0;
  private activeClientsCount = 1;
  private isEnabled = true;
  private processedEventKeys = new Set<string>();

  constructor() {
    if (typeof window !== 'undefined') {
      this.init();
    }
  }

  public init() {
    if (typeof window === 'undefined') return;
    this.connect();
  }

  public getStatus(): RealtimeStatus {
    return this.status;
  }

  public getTransport(): RealtimeTransport {
    return this.transport;
  }

  public getClientCount(): number {
    return this.activeClientsCount;
  }

  private setStatus(status: RealtimeStatus, count?: number, transport?: RealtimeTransport) {
    const statusChanged = this.status !== status;
    const countChanged = typeof count === 'number' && this.activeClientsCount !== count;
    const transportChanged = transport && this.transport !== transport;

    if (!statusChanged && !countChanged && !transportChanged) {
      return;
    }

    this.status = status;
    if (typeof count === 'number') {
      this.activeClientsCount = count;
    }
    if (transport) {
      this.transport = transport;
    }
    this.statusListeners.forEach((fn) => fn(this.status, this.activeClientsCount, this.transport));
  }

  public onStatusChange(callback: (status: RealtimeStatus, count: number, transport: RealtimeTransport) => void): () => void {
    this.statusListeners.add(callback);
    callback(this.status, this.activeClientsCount, this.transport);
    return () => this.statusListeners.delete(callback);
  }

  public subscribe(callback: EventCallback): () => void {
    this.listeners.add(callback);
    return () => this.listeners.delete(callback);
  }

  /**
   * Dispatches incoming event to all active subscribers, deduplicating if needed
   */
  private dispatchEvent(data: RealtimeEventPayload) {
    if (!data) return;

    // Normalize payload if top-level flat format was received
    if (!data.payload) {
      const { eventType, timestamp, activeClientsCount, transport, ...rest } = data as any;
      data.payload = rest;
    }

    // Event deduplication key
    const eventId =
      data.payload?.notification?.id ||
      data.payload?.bookingId ||
      data.payload?.id ||
      data.payload?.booking?.id ||
      `${data.eventType}-${data.timestamp || Date.now()}`;
    const dedupeKey = `${data.eventType}:${eventId}`;

    if (this.processedEventKeys.has(dedupeKey)) {
      return; // Already processed, prevent duplicates
    }

    this.processedEventKeys.add(dedupeKey);
    // Keep deduplication set bounded
    if (this.processedEventKeys.size > 200) {
      const it = this.processedEventKeys.values();
      for (let i = 0; i < 50; i++) {
        const next = it.next();
        if (next.done) break;
        this.processedEventKeys.delete(next.value);
      }
    }

    if (data.activeClientsCount) {
      this.activeClientsCount = data.activeClientsCount;
      this.setStatus(this.status, data.activeClientsCount);
    }

    // Notify all in-memory subscribers synchronously for sub-second reaction
    this.listeners.forEach((fn) => {
      try {
        fn(data);
      } catch (err) {
        console.error('[RealtimeSync listener error]', err);
      }
    });

    // Dispatch global window custom events
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('smartparking:realtime', { detail: data }));
      if (data.eventType === 'ADMIN_NOTIFICATION') {
        window.dispatchEvent(new CustomEvent('smartparking:admin-notification', { detail: data.payload }));
      } else if (data.eventType === 'NEW_BOOKING') {
        window.dispatchEvent(new CustomEvent('smartparking:new-booking', { detail: data.payload }));
      }
    }
  }

  /**
   * Establishes real-time connection. Tries WebSocket first; falls back to SSE.
   */
  private connect() {
    if (!this.isEnabled) return;
    this.cleanup();

    this.setStatus(this.reconnectAttempts > 0 ? 'reconnecting' : 'connecting');

    // Attempt WebSocket first
    if (typeof WebSocket !== 'undefined') {
      this.connectWebSocket();
    } else {
      this.connectSSE();
    }
  }

  private connectWebSocket() {
    let wsUrl: string;
    const base = ApiService.getBaseUrl();

    if (base && !base.startsWith('/api') && (base.startsWith('http://') || base.startsWith('https://'))) {
      const urlObj = new URL(base);
      const wsProto = urlObj.protocol === 'https:' ? 'wss:' : 'ws:';
      const path = urlObj.pathname.replace(/\/+$/, '');
      if (path.endsWith('/api')) {
        wsUrl = `${wsProto}//${urlObj.host}${path}/ws`;
      } else if (path.length > 0 && path !== '/') {
        wsUrl = `${wsProto}//${urlObj.host}${path}/api/ws`;
      } else {
        wsUrl = `${wsProto}//${urlObj.host}/api/ws`;
      }
    } else {
      const wsProto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      let contextPath = '';
      if (window.location.pathname.startsWith('/smartparking')) {
        contextPath = '/smartparking';
      }
      wsUrl = `${wsProto}//${window.location.host}${contextPath}/api/ws`;
    }

    try {
      const ws = new WebSocket(wsUrl);
      this.socket = ws;

      // Fast connection timeout: if WS doesn't connect within 3s, fall back to SSE
      const wsTimeout = setTimeout(() => {
        if (ws.readyState !== WebSocket.OPEN) {
          try { ws.close(); } catch {}
          if (this.transport !== 'sse') {
            this.connectSSE();
          }
        }
      }, 3000);

      ws.onopen = () => {
        clearTimeout(wsTimeout);
        // If SSE was opened as temporary fallback, clean it up now that WS is healthy
        if (this.eventSource) {
          try { this.eventSource.close(); } catch {}
          this.eventSource = null;
        }

        const wasReconnecting = this.reconnectAttempts > 0;
        this.reconnectAttempts = 0;
        this.setStatus('connected', this.activeClientsCount, 'websocket');

        // Start ping heartbeat
        clearInterval(this.pingInterval);
        this.pingInterval = setInterval(() => {
          if (ws.readyState === WebSocket.OPEN) {
            try { ws.send(JSON.stringify({ type: 'ping' })); } catch {}
          }
        }, 20000);

        // If this was a reconnection, broadcast a RECONNECTED event to re-sync missed state
        if (wasReconnecting) {
          this.dispatchEvent({
            eventType: 'RECONNECTED',
            payload: { timestamp: new Date().toISOString() },
            timestamp: new Date().toISOString(),
            transport: 'websocket',
          });
        }
      };

      ws.onmessage = (event: MessageEvent) => {
        try {
          const data: RealtimeEventPayload = JSON.parse(event.data);
          if (data.eventType === 'PONG') return;
          data.transport = 'websocket';
          this.dispatchEvent(data);
        } catch (err) {
          console.warn('[RealtimeSync WS parse error]', err);
        }
      };

      ws.onerror = () => {
        clearTimeout(wsTimeout);
        // Fall back to SSE immediately if WebSocket fails
        if (this.transport !== 'sse') {
          this.connectSSE();
        }
      };

      ws.onclose = () => {
        clearTimeout(wsTimeout);
        clearInterval(this.pingInterval);
        this.socket = null;
        // If SSE is active or connecting, do not mark disconnected or trigger reconnect cascade
        if (this.transport === 'sse' && this.eventSource) {
          return;
        }
        this.setStatus('disconnected', undefined, 'none');
        this.scheduleReconnect();
      };
    } catch {
      this.connectSSE();
    }
  }

  private connectSSE() {
    let sseUrl = '/api/events';
    const base = ApiService.getBaseUrl();
    if (base && !base.startsWith('/api') && (base.startsWith('http://') || base.startsWith('https://'))) {
      const urlObj = new URL(base);
      const path = urlObj.pathname.replace(/\/+$/, '');
      const context = path.endsWith('/api') ? path.slice(0, -4) : (path === '/' ? '' : path);
      sseUrl = `${urlObj.protocol}//${urlObj.host}${context}/api/events`;
    } else if (typeof window !== 'undefined' && window.location.pathname.startsWith('/smartparking')) {
      sseUrl = '/smartparking/api/events';
    }

    try {
      const es = new EventSource(sseUrl);
      this.eventSource = es;

      es.addEventListener('connected', (e: MessageEvent) => {
        try {
          const data = JSON.parse(e.data);
          const wasReconnecting = this.reconnectAttempts > 0;
          this.reconnectAttempts = 0;
          this.setStatus('connected', data.connectedClients || 1, 'sse');

          if (wasReconnecting) {
            this.dispatchEvent({
              eventType: 'RECONNECTED',
              payload: { timestamp: new Date().toISOString() },
              timestamp: new Date().toISOString(),
              transport: 'sse',
            });
          }
        } catch {
          this.setStatus('connected', 1, 'sse');
        }
      });

      es.addEventListener('message', (e: MessageEvent) => {
        try {
          const data: RealtimeEventPayload = JSON.parse(e.data);
          data.transport = 'sse';
          this.dispatchEvent(data);
        } catch (err) {
          console.warn('[RealtimeSync SSE parse error]', err);
        }
      });

      es.onerror = () => {
        if (this.socket && this.socket.readyState === WebSocket.OPEN) {
          // WS is working, ignore SSE error
          return;
        }
        this.setStatus('disconnected', undefined, 'none');
        if (this.eventSource) {
          this.eventSource.close();
          this.eventSource = null;
        }
        this.scheduleReconnect();
      };
    } catch {
      this.setStatus('disconnected', undefined, 'none');
      this.scheduleReconnect();
    }
  }

  private scheduleReconnect() {
    clearTimeout(this.reconnectTimeout);
    // Exponential backoff starting at 1.2s, capped at 10s
    const delay = Math.min(10000, 1200 * Math.pow(1.5, this.reconnectAttempts));
    this.reconnectAttempts++;

    this.reconnectTimeout = setTimeout(() => {
      this.connect();
    }, delay);
  }

  private cleanup() {
    if (this.socket) {
      try { this.socket.close(); } catch {}
      this.socket = null;
    }
    if (this.eventSource) {
      try { this.eventSource.close(); } catch {}
      this.eventSource = null;
    }
    clearInterval(this.pingInterval);
  }

  /**
   * Broadcast an event to all other devices via the server
   */
  public async broadcast(eventType: string, payload: any): Promise<boolean> {
    try {
      const base = ApiService.getBaseUrl();
      const res = await fetch(`${base}/realtime/broadcast`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ eventType, payload }),
      });
      return res.ok;
    } catch {
      return false;
    }
  }
}

export const RealtimeSync = new RealtimeSyncManager();
